import React from 'react'
import Product from "../components/Product/Product"
function AllProductForCosmetic() {
  return (
    <div>   <Product></Product></div>
  )
}

export default AllProductForCosmetic