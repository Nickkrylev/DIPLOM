import React from 'react'
import AdminEnter from '../components/AdminEnter/AdminEnter'
function Admin() {
  return (
    <AdminEnter></AdminEnter>
  )
}

export default Admin