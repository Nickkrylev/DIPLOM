import React from 'react'
import Product from "../components/Product/Product"
function AllProductForMen() {
  return (
    <div><Product></Product></div>
  )
}

export default AllProductForMen