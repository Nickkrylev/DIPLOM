import React from 'react'
import Product from "../components/Product/Product"
function AllProductForGifs() {
  return (
    <div><Product></Product></div>
  )
}

export default AllProductForGifs